Oni's Internet and PC Speed Tweaks

These three zip files are meant to change graphics and network settings to better support slow and fast PCs and internet speeds. Ideally one of them should limit lag issues and bugs (rubber banding, T-posing, invisible enemies, etc.)

To use, unzip into your root Vegas directory (the one above KellerGame) and replace the files.
To revert, simply unzip the default zip file and replace.