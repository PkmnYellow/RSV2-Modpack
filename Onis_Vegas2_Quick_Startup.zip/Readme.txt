For Oni's R6 Vegas Quick Startup:

Unzip into your KellerGame\Startup folder