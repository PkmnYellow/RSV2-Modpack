Oni's Vegas2 Map Expansion

This makes it easier to have 16 players on Story & Terrorist Hunt (still requires TeknoR6 Mod)
AND allows the use of Story maps on Terrorist Hunt & Versus Modes (Deathmatch, Team Deathmatch, Attack & Defend.)
TH are only empty maps to explore. Versus modes may have random spawn points or mat not. A&D includes story enemies and triggers into Versus play.

To install, just Unzip into your KellerGame/CookedPC folder and replace the map files already in there.
You'll probably want to make a backup you can unzip to revert to normal map settings.